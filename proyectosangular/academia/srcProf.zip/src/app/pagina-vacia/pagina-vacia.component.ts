import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina-vacia',
  templateUrl: './pagina-vacia.component.html',
  styleUrls: ['./pagina-vacia.component.css']
})
export class PaginaVaciaComponent {

}
