import React from 'react';
//imr

//ccc
class ListarGrupo extends React.Component {
    constructor(props) {
        super(props);
    }
    state = {  }
    render() { 
        return ( 
            <div>
                <h2>ListarGrupo desde react otra pagina</h2>
            </div>
         );
    }
}
 
export default ListarGrupo;